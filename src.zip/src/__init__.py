# Import packages
from flask import Flask
app = Flask(__name__)

import src.views